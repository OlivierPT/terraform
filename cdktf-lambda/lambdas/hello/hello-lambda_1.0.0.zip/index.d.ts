import { APIGatewayProxyHandlerV2 } from "aws-lambda";
export declare const handler: APIGatewayProxyHandlerV2;
